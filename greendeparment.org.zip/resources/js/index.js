import React from "react";
import ReactDOM from "react-dom";
import App from "./pages/App";

const container = document.getElementById("app");

ReactDOM.render(<App />, container);
